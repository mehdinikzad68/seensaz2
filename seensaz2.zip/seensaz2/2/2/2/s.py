import telepot


bot = telepot.Bot("369687096:AAFCnXFOfwnv68mEfXSKX0DphprINh6Z3sI")
text = "ساعت طلايي!\nتا ساعت ١٢ امشب به ازاى هر زيرمجموعه جديد به جاي ١٠ سكه، ٢٠ سكه دريافت كنيد\nبا سکه های دریافتی میتوانید بازدید پست‌های کانال یا چالش خود را بالا ببرید.\n\n\nبراى دريافت لينك خود روي دكمه زيرمجموعه گيري در ربات كليك كنيد\n@ViewRobot"
arian = bot.sendMessage("@viewrobo",text)


print(arian)
