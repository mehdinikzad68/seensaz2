from __main__ import *
from utils import *
from core import keyboard
patterns = [
r'.*'
]

def keyboard2(array):
    kb = []
    kb2 = []
    for i in array:
        for a in i:
            kb2.append(KeyboardButton(text=a))
        kb.append(kb2)
        kb2 = []
    return ReplyKeyboardMarkup(keyboard=kb,resize_keyboard=True,one_time_keyboard=False)

name = "interface"
cron = None
def run(msg, matches, User):
    if 'سکه رایگان روزانه' in msg['text']:
        if time.time() > User.time:
            User.updateinfo({"coin":User.coin+10,'time':time.time()+86400})
            kb=[['مشاهده تبلیغ'],['بازگشت']]
            timenow = time.strftime("%H:%M:%S", time.gmtime(86399))
            bot.sendMessage(User.user_id,"10 سکه به حساب شما اضافه شد\nروزانه با پیام دادن به ربات 10 سکه جایزه بگیرید\nزمان دریافت سکه رایگان بعدی {} دیگر".format(timenow))
            return
        else:
            timenow = time.strftime("%H:%M:%S", time.gmtime(User.time-time.time()))
            bot.sendMessage(User.user_id,"زمان دریافت سکه رایگان بعدی {} دیگر".format(timenow))
            return
    if '🚀 انتقال سکه' in msg['text']:
        kb=[['بازگشت']]
        kb = keyboard2(kb)
        db.hset("users:"+str(msg['from']['id']),'step','enteghal_seke 1 ')
        bot.sendMessage(User.user_id,lang['enteghal'],reply_markup=kb)
    if '💎 جمع آوری سکه رایگان' in msg['text']:
        #kb=[['مشاهده تبلیغ'],['بازگشت']]
        kb=[['مشاهده تبلیغ','سکه رایگان روزانه'],['بازگشت']]
        if time.time() > User.time:
            kb=[['مشاهده تبلیغ','سکه رایگان روزانه'],['بازگشت']]
        kb = keyboard2(kb)
        bot.sendMessage(User.user_id,lang['get_free_coin'],reply_markup=kb)
    if 'بازگشت' in msg['text']:
        bot.sendMessage(User.user_id,lang['back'],reply_markup=default_keyboard)
        db.hdel("users:"+str(msg['from']['id']),'step')
    if '👤 حساب کاربری من' in msg['text']:
        coin = db.get('coin:'+str(User.user_id))
        coin = coin if coin else 0
        posts = User.getuserposts()
        if len(posts) != 0:
            text = '📨 وضعیت آخرین سفارش شما:\n'
        else:
            text = ''
        for i in posts:
            text = text+'بازدید های باقیمانده سفارش‌ {}: {}\n'.format(i['post_id'].lower(),i['views'])
        bot.sendMessage(User.user_id,lang['myuseraccount'].format(coin,User.user_id,text))
    if '🎯 ثبت و آمار سفارش' in msg['text']:
        coin = db.get('coin:'+str(User.user_id))
        coin = coin if coin else 0
        if int(coin) < 25:
            db.hdel("users:"+str(msg['from']['id']),'step')
            return bot.sendMessage(User.user_id,lang['not_enough_coin'],reply_markup=default_keyboard)
        phone_number = db.hget('phone',msg['from']['id'])
        db.hset("users:"+str(msg['from']['id']),'step','send_ad')
        keyboard = keyboard2([['انصراف','📊 آمار']])
        bot.sendMessage(User.user_id,lang['newad'],reply_markup=keyboard)
    if 'آمار' in msg['text'] and not 'ثبت' in msg['text']:
        coin = db.get('coin:'+str(User.user_id))
        coin = coin if coin else 0
        posts = User.getuserposts()
        if len(posts) != 0:
            text = '📨 وضعیت آخرین سفارش شما:\n'
        else:
            bot.sendMessage(User.user_id,'شما پستی ندارید')
        for i in posts:
            text = text+'👈 سفارش کد {} با {} بازدید باقیمانده\n'.format(i['post_id'].lower(),i['views'])
        bot.sendMessage(User.user_id,text)
    if 'انصراف' in msg['text']:
        db.hdel("users:"+str(msg['from']['id']),'step')
        bot.sendMessage(User.user_id,lang['back'],reply_markup=default_keyboard)
    if '❓راهنما' in msg['text']:
        bot.sendMessage(User.user_id,lang['help'])
    if '👥 زیرمجموعه گیری' in msg['text']:
        bot.sendMessage(User.user_id,lang['ref1'].format(botuser,User.user_id))
        bot.sendMessage(User.user_id,lang['ref2'].format(botuser,User.user_id),disable_web_page_preview=True)
