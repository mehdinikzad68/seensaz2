from __main__ import *
from utils import *
import math
patterns = [
r'.*',
]
name = "start"
cron = None
def run(msg, matches, User):
    if '💳 فروشگاه' in msg['text']:
        if msg:
            return bot.sendMessage(User.user_id,'فعلا فروشگاه تعطیله\nبه زودی بازش میکنیم😁')
        keyboard = generate_keyboard_buy()
        bot.sendMessage(User.user_id,'برای خرید سکه روی یکی از گزینه های پایین کلیک کن',reply_markup=keyboard)
        db.hset("users:"+str(msg['from']['id']),'step','buy_coin')
        return
        
    if 'buy_coin' in msg['text']:
        matches = re.match(r'!!buy_coin ([\d]+)', msg['text'])
        text = msg['text'].replace('!!buy_coin ','')
        if matches:
            matches = matches.groups()[0]
            print(matches)
        if not 'انصراف' in msg['text'] and int(matches) in buycoin:
            db.hdel("users:"+str(msg['from']['id']),'step')
            k = InlineKeyboardMarkup(inline_keyboard=[[ InlineKeyboardButton(text='برای خرید کلیک کنید', url=User.buycoin(matches))]])
            bot.sendMessage(User.user_id,'برای خرید {} روی دکمه زیر کلیک کنید'.format(text),reply_markup=k)
        
