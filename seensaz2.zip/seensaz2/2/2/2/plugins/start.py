
from __main__ import *
from utils import *

patterns = [
r'^[#/!]start (ref)-([\d]+)$',
r'^[#/!](start)$',
]

name = "start"
cron = None
def run(msg, matches, User):

    if matches[0] == 'ref':
        bot.sendMessage(User.user_id,lang['start'],reply_markup=default_keyboard)
        if int(matches[1]) != User.user_id and not User.is_reffered:
            User.updateinfo({'is_reffered':True})
            User.updateinfo({'step':False,'tc':False,'tci':False})
            User.updateinfo({'coin':User.coin+10})
#            User.updateinfo({'refs':User.refs+1})
            refs = db.users.find({"user_id":int(matches[1])})[0]
            ref22 = refs
            refs=refs['refs'] if 'refs' in refs else 0
            db.users.update_one({"user_id":int(matches[1])},{"$set":{"refs":refs+1}})
            ref = ttl.get('server:ref')
            ref2 = int(ref) if ref else 0
            ref = '+{}(ساعت طلایی)'.format(ref) if ref else ''
            reff = 'زیرمجموعه های شما در ساعت طلایی: {}'.format(User.refs2) if ref != '' else ''
            #try:
            user = db.users.find({'user_id':int(matches[1])})[0]
            db.users.update_one({'user_id':int(matches[1])}, {'$set':{'coin':user['coin']+10+ref2}})
            if ttl.get('server:ref'):
                refss = ref22['refs2'] if 'refs2' in ref22 else 0
                db.users.update_one({"user_id":int(matches[1])},{"$set":{"refs2":refss+1}})
                bot.sendMessage(matches[1],lang['new_ref'].format(ref,refs+1,refss+1),reply_markup=default_keyboard)
            else:
                bot.sendMessage(matches[1],lang['new_ref'].format(ref,refs+1,reff),reply_markup=default_keyboard)
            #except Exception as e :
             #  print(e)

    if matches[0] == 'start':
         if is_sudo(User.user_id):
            bot.sendPhoto(User.user_id,"AgADBAADDKgxG0ZxwVGe_y9uun5J_BO5ZBkABBNwgTCAaST6mIADAAEC")
            bot.sendMessage(User.user_id,lang['storebot2'],disable_web_page_preview=True)
         User.updateinfo({'step':False,'tc':False,'tci':False})
         User.updateinfo({'is_reffered':True})
         if not User.is_reffered:
            User.updateinfo({'coin':User.coin+10})
         return bot.sendMessage(User.user_id,lang['start'],reply_markup=default_keyboard)
