from __main__ import *
from utils import *
import math
patterns = [
r'.*',
]
name = "start"
cron = None
def run(msg, matches, User):
    if '📮 ارتباط با ما' in msg['text']:
        keyboard=[
		[KeyboardButton(text='انصراف')]]
        User.updateinfo({'step':'contact_us'})
        bot.sendMessage(User.user_id,lang['contact_us'],reply_markup=ReplyKeyboardMarkup(keyboard=keyboard,resize_keyboard=True,one_time_keyboard=False))
        return
    if User.step == 'contact_us' and not 'انصراف' in msg['text'] and not '/start' in msg['text']:
        User.updateinfo({'step':False})
        for i in config.sudo_users:
            try:
                bot.forwardMessage(i,User.user_id,msg['message_id'])
            except Exception as e:
                print(e)
                bot.sendMessage(i,msg['text']+'\n\n{}\n{}\n{}'.format(User.username,User.user_id,User.firstname))
        return bot.sendMessage(msg['from']['id'], lang['contact_us2'],reply_markup=default_keyboard)
