
from __main__ import *
from utils import *

patterns = [
r'^(.*)',
]

name = "start"
cron = None
def run(msg, matches, User):
    print(msg['text'])
    if '📌نظرات کاربران به ربات' in msg['text']:
        User.updateinfo({'reviewid':False})
        User.show_reviews()
    if '!!callback' in msg['text']:
        if 'reviews' in msg['text']:
        
            User.show_reviews_callback(msg['id'])