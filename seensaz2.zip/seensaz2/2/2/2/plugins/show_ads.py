from __main__ import *
from utils import *
import math
patterns = [
r'.*',
]






name = "ads"
cron = None
def run(msg, matches, User):
    coin = User.coin
    if '/start' in msg['text']: return
    if 'مشاهده تبلیغ' in msg['text']:
        getcm=bot.getChatMember(config.channel2,User.user_id)
        if getcm['status'] == 'left' and User.viewedads > 2:
            k = InlineKeyboardMarkup(inline_keyboard=[[ InlineKeyboardButton(text='ورود به کانال', url="https://telegram.me/ViewRobo")]]) 
            return bot.sendMessage(User.user_id,lang['channel'].format(config.channel2),reply_markup=k)
        time = ttl.get('vpost'+str(User.user_id)) if not is_sudo(User.user_id) else False
        if time:
          xp = ttl.ttl('vpost'+str(User.user_id))
          if xp != None:
               ttl.setex('vpost'+str(User.user_id),'True',3)
               return bot.sendMessage(User.user_id,lang['masdod'])
        ttl.setex('vpost'+str(User.user_id),'True',3)
        User.showpost()
    if User.step == 'send_ad':
        if 'انصراف' in msg['text']: return
        forward = False
        for i in msg:
            if 'forward' in i:
                forward = True
                break
        

        md5 = hashlib.md5()
        md5.update(msg['text'].replace('!!send_ad ','').replace('!!price_list ','').encode('utf-8'))

        p =  db.posts.find({'md5':md5.hexdigest(),'finished':False})
        #if p.count() != 0:
        #        User.updateinfo({'step':False})
        #        return bot.sendMessage(User.user_id,"این پست با شماره پیگیری {} قبلا به ربات ارسال شده است".format(p[0]['post_id']),reply_markup=default_keyboard)
        User.updateinfo({'step':'price_list'})
  
        if forward:
            ttl.hset("post:tmp",User.user_id,msg['message_id'])
            ttl.hset("post:tmp:chat_id",User.user_id,msg['chat']['id'])
            ttl.hset("post:tmp:md5",User.user_id,md5.hexdigest())
        else:
            try:
                a = bot.forwardMessage("@SeenMeUpPlease",msg['chat']['id'],msg['message_id'])
                ttl.hset("post:tmp",User.user_id,a['message_id'])
                ttl.hset("post:tmp:chat_id",User.user_id,"@SeenMeUpPlease")
                ttl.hset("post:tmp:md5",User.user_id,md5.hexdigest())
            except:
                if not 'forward_date' in msg:
                    return bot.sendMessage(User.user_id,lang['must_fwd'])
                if not 'forward_from_chat' in msg or msg['forward_from_chat']['type'] != 'channel':
                    return bot.sendMessage(User.user_id,'تبلیغ شما حتما باید از کانال فروارد شده باشد')
        bot.sendMessage(User.user_id,lang['price_text'],reply_markup=generate_keyboard(coin))

    if User.step == 'price_list':
        text = msg['text'].replace('!!price_list ','')
        matches = re.match(r'درخواست ([\d]+)', text)
        matches2 = re.match(r'([\d]+)', text)
        if matches2:
            matches = matches2.groups()[0]
        elif matches:
            matches = matches.groups()[0]
        if matches:
            coin = math.floor(int(matches)*24/20)
            if coin < 20:
                return bot.sendMessage(User.user_id,"تعداد سكه ها كمتر از حد مجاز ميباشد")
            if User.coin < coin:
                return bot.sendMessage(User.user_id,"سکه های شما کافی نیست")
            getcoin = User.coin
            User.updateinfo({'coin':User.coin-coin})
            User.updateinfo({'step':False})
            msg_id = ttl.hget("post:tmp",User.user_id)
            md5 = ttl.hget("post:tmp:md5",User.user_id)
            chat_id = ttl.hget("post:tmp:chat_id",User.user_id)
            post = User.addpost(chat_id,msg_id,int(matches),User.user_id,md5)
            ttl.hdel("post:tmp",User.user_id)
            ttl.hdel("post:tmp:chat_id",User.user_id)
            ttl.hdel("users:"+str(msg['from']['id']),'step')
            
            if chat_id.isdigit() and int(chat_id) != int(msg['chat']['id']):
                bot.forwardMessage(msg['chat']['id'],msg['chat']['id'],post['msg_id'])
            bot.sendMessage(User.user_id,lang['post_finish'].format(matches,math.floor(coin),post['post_id'].lower()),reply_markup=default_keyboard)
            

