from __main__ import *
from utils import *
from core import keyboard
import time
patterns = [
r'(.*)'
]

def keyboard2(array):
    kb = []
    kb2 = []
    for i in array:
        for a in i:
            kb2.append(KeyboardButton(text=a))
        kb.append(kb2)
        kb2 = []
    return ReplyKeyboardMarkup(keyboard=kb,resize_keyboard=True,one_time_keyboard=False)

name = "interface"
cron = None
def run(msg, matches, User):
    if '/creator' in msg['text']:
        creator = ttl.get('creator')
        return bot.sendMessage(User.user_id,creator)
    if 'سکه رایگان روزانه' in msg['text']:
        if User.viewedads < 9:
            bot.sendMessage(User.user_id,"برای دریافت سکه رایگان حداقل باید 10 تبلیغ ببینید")
            return
        if time.time() > User.time:
            User.updateinfo({"coin":User.coin+10,'time':time.time()+86400})
            kb=[['مشاهده تبلیغ'],['بازگشت']]
            timenow = time.strftime("%H:%M:%S", time.gmtime(86399))
            bot.sendMessage(User.user_id,"10 سکه به حساب شما اضافه شد\nروزانه با پیام دادن به ربات 10 سکه رایگان جایزه بگیرید\nزمان دریافت سکه رایگان بعدی {} دیگر است".format(timenow))
            return
        else:
            timenow = time.strftime("%H:%M:%S", time.gmtime(User.time-time.time()))
            bot.sendMessage(User.user_id,"زمان دریافت سکه رایگان بعدی {} دیگر است".format(timenow))
            return
    if matches[0] == '🚀 انتقال سکه':
        kb=[['بازگشت']]
        kb = keyboard2(kb)
        User.updateinfo({'step':'transfer_coin','tc':1})
        bot.sendMessage(User.user_id,lang['enteghal'],reply_markup=kb)
    if matches[0] == 'اشتراک شماره':
        markup = ReplyKeyboardMarkup(keyboard=[
		[KeyboardButton(text='اشتراک گذاری', request_contact=True), KeyboardButton(text='بازگشت')],
      ],resize_keyboard=True,one_time_keyboard=False)
        bot.sendMessage(User.user_id,'با کلیک روی دکمه زیر و ارسال شماره خودتان\n۱۵ سکه هدیه بگیرید',reply_markup=markup)
    if matches[0] == '💎 جمع آوری سکه رایگان':
        kb=[['مشاهده تبلیغ','سکه رایگان روزانه'],['بازگشت']]
        if not User.phone:
            kb=[['مشاهده تبلیغ',"اشتراک شماره"],['بازگشت','سکه رایگان روزانه']]
        kb = keyboard2(kb)
        bot.sendMessage(User.user_id,lang['get_free_coin'],reply_markup=kb)

    if matches[0] == 'بازگشت':
        bot.sendMessage(User.user_id,lang['back'],reply_markup=default_keyboard)
        User.updateinfo({'step':False,'tc':False,'tci':False})

    if matches[0] == '👤 حساب کاربری من':
        posts = User.getuserposts()
        text = ''
        t = 0
        if len(posts) != 0:
            text = '📨 وضعیت آخرین سفارش شما:\n'
        else:
            text = ''
        for i in posts:
            t+=1
            text = text+'{} سفارش کد {} با {} بازدید باقیمانده\n'.format(str(t)+'- ',i['post_id'].lower(),i['views'])

        bot.sendMessage(User.user_id,lang['myuseraccount'].format(User.coin,User.user_id,text))

    if '🎯 ثبت تبلیغ' in msg['text']:
        if int(User.coin) < 23:
            User.updateinfo({'step':False})
            return bot.sendMessage(User.user_id,lang['not_enough_coin'],reply_markup=default_keyboard)
        User.updateinfo({'step':"send_ad"})
        keyboard = keyboard2([['انصراف']])
        bot.sendMessage(User.user_id,lang['newad'],reply_markup=keyboard)

    if 'انصراف' in msg['text']:
        User.updateinfo({'step':False})
        bot.sendMessage(User.user_id,lang['back'],reply_markup=default_keyboard)

    if '❓راهنما' in msg['text'] or '/help' in msg['text']:
        bot.sendMessage(User.user_id,lang['help'])

    if '👥 زیرمجموعه گیری' in msg['text']:
        ref = ttl.get('server:ref')
        ref = '+{}(ساعت طلایی)'.format(ref) if ref else ''
        ref2 = 'زیرمجموعه های شما در ساعت طلایی: {}'.format(User.refs2) if ref != '' else ''
        bot.sendMessage(User.user_id,lang['ref1'].format(botuser,User.user_id))
        bot.sendMessage(User.user_id,lang['ref2'].format(ref,botuser,User.user_id,User.refs,ref2),disable_web_page_preview=True)
