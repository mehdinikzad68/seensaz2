from __main__ import *
from utils import *
import math
patterns = [
r'([\d]+)',
]


def keyboard2(array):
    kb = []
    kb2 = []
    for i in array:
        for a in i:
            kb2.append(KeyboardButton(text=a))
        kb.append(kb2)
        kb2 = []
    return ReplyKeyboardMarkup(keyboard=kb,resize_keyboard=True,one_time_keyboard=False)


name = "start"
cron = None
def run(msg, matches, User):
    if User.step == 'transfer_coin' and User.tc == 1:
        kb=[['بازگشت']]
        if db.users.find({'user_id': int(matches[0])}).count() == 0 or int(matches[0]) == User.user_id:
            return bot.sendMessage(User.user_id,lang['enteghal_namotabar'])
        kb = keyboard2(kb)
        User.updateinfo({'tci':int(matches[0]),'tc':2})
        bot.sendMessage(User.user_id,lang['enteghal2'].format(User.coin),reply_markup=kb)
    if User.step == 'transfer_coin' and User.tc == 2:
        kb=[['بازگشت']]
        kb = keyboard2(kb)
        if int(matches[0]) > User.coin:
            return bot.sendMessage(User.user_id,lang['enteghal_no_credit'].format(User.coin,User.coin),reply_markup=kb)
    
        User.updateinfo({'step':False,'tc':0,'coin':User.coin-int(matches[0])})
        
        user = db.users.find({'user_id':int(User.tci)})[0]
        db.users.update_one({'user_id':int(User.tci)}, {'$set':{'coin':user['coin']+int(matches[0])}})
        bot.sendMessage(int(User.tci),"✅ مقدار {} سکه از کاربر {} به شما انتقال داده شد".format(matches[0],User.user_id),reply_markup=default_keyboard)
        bot.sendMessage(User.user_id,lang['enteghal_finish'].format(matches[0],User.tci),reply_markup=default_keyboard)
