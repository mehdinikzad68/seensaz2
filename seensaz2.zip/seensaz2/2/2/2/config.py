sudo_users = [379856063]
TOKEN = "369687096:AAFCnXFOfwnv68mEfXSKX0DphprINh6Z3sI"
channel = '@MyFuckingPrivateChannel'
channel2 = "@ViewRobo"
