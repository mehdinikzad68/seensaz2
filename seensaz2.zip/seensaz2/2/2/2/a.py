import socket
import sys
import json
import threading
from pymongo import MongoClient
import demjson
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

db = MongoClient().arian.seensaz

server_address = ('', 10000)
print('starting up on {} port {}'.format(*server_address))
sock.bind(server_address)

sock.listen(1)


def send_data(con,data):
    
    data = data.split('-')
    print(data[0])

    if data[0] =='users':
        d = db.users
    else:
        d = db.posts
    print(data[1])
    data = {"data":list(d.find({data[1]:int(data[2])}))}
    connection.sendall(str(data).encode())
    con.close()

while True:
    print('waiting for a connection')
    connection, client_address = sock.accept()
    try:
        print('connection from', client_address)
        while True:
            data = connection.recv(10000000000)
            try:
                data = data.decode('utf-8')
            except:
                data = data
            if data:
                print('sending data back to the client')
                if not 'Jomishka3164955' in data:
                    connection.sendall('go fuck yourself bitch'.encode())
                    connection.close()
                else:
                    data = data.replace('Jomishka3164955','')
                    res = threading.Thread(target = send_data, args=(connection,data))
                    res.start()
                break
            else:
                print('no data from', client_address)
                connection.close()
                break

    except:
        None
