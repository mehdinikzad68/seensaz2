from utils import *
from random import randint
import random, string, demjson
import math, requests
import hashlib
import time
def is_sudo(user_id):
    return user_id in config.sudo_users


def keyboard(array):
    kb = []
    kb2 = []
    for i in array:
        for a in i:
            kb2.append(KeyboardButton(text=a))
        kb.append(kb2)
        kb2 = []
    return ReplyKeyboardMarkup(keyboard=kb,resize_keyboard=True,one_time_keyboard=False)




def generate_keyboard(coin):
    kb = [['انصراف']]
    for i in price:
        if i <= coin:
            kb.append(['درخواست {} بازدید | {} سکه'.format(i,math.floor(i*24/20))])
    return keyboard(kb)


def generate_keyboard_buy():
    kb = [['انصراف']]
    for i in buycoin:
         kb.append(['{} سکه | {} هزار تومان'.format(i,math.floor(i*5))])
    return keyboard(kb)




'''                   Keyboards                       '''

default_keyboard = keyboard([['💎 جمع آوری سکه رایگان'],
        ['💳 فروشگاه','🚀 انتقال سکه','🎯 ثبت تبلیغ'],
        ['👥 زیرمجموعه گیری','👤 حساب کاربری من'],
        ['📌نظرات کاربران به ربات'],
        ['📮 ارتباط با ما','❓راهنما']
        ])





'''                 keyboards END                    '''




class User:

    def __init__(self,msg):
        msg = msg['from']
        self.user_id = msg['id']
        self.firstname = msg['first_name']
        self.db = db.users.find({'user_id':msg['id']}).limit(1)[0]
        self.step = str(self.db['step']) if 'step' in self.db else False
        self.coin = math.floor(self.db['coin']) if 'coin' in self.db else 0
        self.count = self.db['count'] if 'count' in self.db else 0
        self.is_reffered = self.db['is_reffered'] if 'is_reffered' in self.db else False
        self.refs = self.db['refs'] if 'refs' in self.db else 0
        self.total_coin = self.db['total_coin'] if 'total_coin' in self.db else 0
        self.viewedads = self.db['viewedads'] if 'viewedads' in self.db else 0
        self.refs2 = self.db['refs2'] if 'refs2' in self.db else 0
        self.phone = '+'+str(self.db['phone']) if 'phone' in self.db else False
        self.storebot = self.db['storebot'] if 'storebot' in self.db else 0
        self.stars = self.db['stars'] if 'stars' in self.db else 0
        self.reviews = self.db['reviews'] if 'reviews' in self.db else []
        self.reviewid = self.db['reviewid'] if 'reviewid' in self.db else False
        self.reviewid2 = self.db['reviewid2'] if 'reviewid2' in self.db else 0
        self.time = self.db['time'] if 'time' in self.db else time.time()-1
        try:
            self.username =  '@'+self.db['username'] if 'username' != None else 'asdasdasd'
        except:
            self.username = "None"
        self.tc = self.db['tc'] if 'tc' in self.db else 0
        self.tci = self.db['tci'] if 'tci' in self.db else 0
        
    def show_reviews(self):
        
        resp = requests.get("https://storebot.me/api/bots/reviews?id=viewrobot&count=50")
        resp2 = requests.get("https://storebot.me/api/bots/ViewRobot")
        data = demjson.decode(resp.text)
        data2 = demjson.decode(resp2.text)
        k = InlineKeyboardMarkup(inline_keyboard=[[ InlineKeyboardButton(text='▶️مشاهده نظر بعدی', callback_data="reviews")]])
        try:
            for i in data:
                if not int(i['user']['id']) in self.reviews:
                    username = '@'+i['user']['username'] if 'username' in i['user'] else "---"
                    #db.users.update_one({'user_id':self.user_id},"$push": {'reviews':int(i['user']['id'])})
                    db.users.update_one({'user_id':self.user_id}, {"$push": {'reviews': int(i['user']['id'])}})
                    review = """
👥 مجموع امتیازات: {} - {}/5
👥 تعداد نظرات: {}
✳️ مشخصات فرستنده
    🔹 نام کاربر: {}
    🔹 یوزرنیم: {}
    🔹 ایدی کاربر: {}
    🔹 امتیاز: {}

✅نظر: {}

برای مشاهده تمامی نظرات روی لینک زیر کلیک کنید
storebot.me/bot/ViewRobot    """.format(data2['reviews_n'],float("{0:.2f}".format(data2['rating'])),data2['comments_n'],i['user']['firstName'].replace('\n',' ').replace('allen','')[:15],username,i['user']['id'],"⭐️"*i['stars'],i['review'])
                    text = bot.sendMessage(self.user_id,review,disable_web_page_preview=True,reply_markup=k)
                    self.updateinfo({'reviewid':text['message_id']})
                    print(text)
                    return
            text = bot.sendMessage(self.user_id,'نظری برای مشاهده وجود ندارد',disable_web_page_preview=True,reply_markup=k)
            self.updateinfo({'reviewid':text['message_id']})
            #self.updateinfo({'reviewid2':text['id']})        
        except Exception as e:
            print(e)
                    
    def show_reviews_callback(self,queryid):
        #bot.answerCallbackQuery(queryid, "چند لحظه صبر کنید...", False)
        random_num = randint(0,1000)
        resp = requests.get("https://storebot.me/api/bots/reviews?id=viewrobot&count=50")
        resp2 = requests.get("https://storebot.me/api/bots/ViewRobot")
        data = demjson.decode(resp.text)
        data2 = demjson.decode(resp2.text)
        k = InlineKeyboardMarkup(inline_keyboard=[[ InlineKeyboardButton(text='▶️مشاهده نظر بعدی', callback_data="reviews")]])
        try:
            for i in data:
                if not int(i['user']['id']) in self.reviews:
                    username = '@'+i['user']['username'] if 'username' in i['user'] else "---"
                    #db.users.update_one({'user_id':self.user_id},"$push": {'reviews':int(i['user']['id'])})
                    db.users.update_one({'user_id':self.user_id}, {"$push": {'reviews': int(i['user']['id'])}})
                    review = """
👥 مجموع امتیازات: {} - {}/5
👥 تعداد نظرات: {}
✳️ مشخصات فرستنده
    🔹 نام کاربر: {}
    🔹 یوزرنیم: {}
    🔹 ایدی کاربر: {}
    🔹 امتیاز: {}

✅نظر: {}

برای مشاهده تمامی نظرات روی لینک زیر کلیک کنید
storebot.me/bot/ViewRobot    """.format(data2['reviews_n'],float("{0:.2f}".format(data2['rating'])),data2['comments_n'],i['user']['firstName'].replace('\n',' ').replace('allen','')[:15],username,i['user']['id'],"⭐️"*i['stars'],i['review'])
                    if self.reviewid:
                        bot.answerCallbackQuery(queryid, "مشاهده نظر بعدی", False)
                        bot.editMessageText((self.user_id, self.reviewid), review, "html", True, k)
                        return
            if self.reviewid:
                bot.answerCallbackQuery(queryid, "نظری برای مشاهده وجود ندارد", False)
                bot.editMessageText((self.user_id, self.reviewid), 'نظری برای مشاهده وجود ندارد', "html", True, k)
                return
        except Exception as e:
            print(e)
                    
    
    def updateinfo(self,data):
        try:
            db.users.update_one({'user_id':self.user_id}, {'$set':data})
            return True
        except:
            return False

#    def getposts(self):
##        posts = db.posts.
        #print(posts)
 #       all_posts = {"posts":[],"count":len(posts)}
 #       for post in posts:
 #           #print(post)
 #           post = demjson.decode(post)
 #           all_posts['posts'].append(post)
 #       return all_posts

    def buycoin(self,coin):
        coin = int(coin)*5
        link = 'http://yeo.ir/api.php?url=https://telegram.me/{}?start=new'.format(botuser)
        f = requests.get(link)
        res = f.text
        links = 'http://seensaz.ir/amir/zarin.php?id=8f040a9c-b929-11e6-a575-005056a205be&amount={}&description=خرید سکه&call={}'.format(coin,res)
        fs = requests.get(links)
        ress = fs.text
        te = '{}${}'.format(ress,coin)
        db.setex('key:'+str(self.user_id),te,10*60)
        return 'https://www.zarinpal.com/pg/StartPay/{}'.format(ress)

    def addpost(self,chat_id,msg_id,views,sender_id,md5):
        post_id = ''.join(random.choice(string.hexdigits) for x in range(10)).lower()
        data = {}
        data['chat_id'] = chat_id
        data['msg_id'] = msg_id
        data['views'] = views
        data['sender_id'] = sender_id
        data['post_id'] = post_id
        data['views2'] = views
        data['finished'] = False
        data['md5'] = md5
        data['viewed'] = []
        try:
            a=bot.forwardMessage(config.channel, data['chat_id'], data['msg_id'])
            k = InlineKeyboardMarkup(inline_keyboard=[[ InlineKeyboardButton(text='بلاک کردن کاربر', callback_data="block {}".format(post_id))],[ InlineKeyboardButton(text='حذف تبلیغ', callback_data="remove {}".format(post_id))]])

            text = 'نام کاربر: {}\nیوزرنیم: {}\nایدی کاربر: {}'.format(self.firstname, '@'+str(self.username),self.user_id)
            arian = bot.sendMessage(config.channel,"انجام عملیات\n"+text+'\nتعداد ویو:‌ {}'.format(views),reply_markup=k,reply_to_message_id=a['message_id'])

            data['channel_id'] = arian['chat']['id']
            data['channel_msg_id'] = arian['message_id']
        except Exception as e:
            print(e)
        db.posts.update_one({'post_id':post_id}, {'$set':data}, upsert=True)
        return data


    def deletepost(self,post_id):
        posts = db.posts.find({"post_id":post_id})[0]
        db.posts.delete_many({'post_id':post_id})
        bot.sendMessage(posts['sender_id'],"تبلیغ شما توسط گروه پشتیبانی پاک شد\nکد تبلیغ: {}".format(post_id.lower()))
    def deletepostsilent(self,post_id):
        posts = db.posts.find({"post_id":post_id})[0]
        db.posts.delete_many({'post_id':post_id})
        #bot.sendMessage(posts['sender_id'],"تبلیغ شما توسط گروه پشتیبانی پاک شد\nکد تبلیغ: {}".format(post_id.lower()))


    def getpost(self,post_id):
        posts = db.smembers('posts')
        for p in posts:
            p2 = demjson.decode(p)
            if p2['post_id'] == post_id:
                sender = p2['sender_id']
                return p2
        return {'post_id':1234}

    def getuserposts(self):
        data = []
        posts = db.posts.find({"sender_id":self.user_id,"finished":False})
        for i in posts:
            data.append(i)
        return data


    def showpost(self):
        posts = db.posts.find({"$and": [{"finished":False},{"sender_id":{"$ne":self.user_id}},{"viewed": {"$ne": self.user_id}}]})
        if posts.count(True) == 0:
            return bot.sendMessage(self.user_id,lang['no_ads'])
        random_num = randint(0,posts.count()-1)
        post = posts[random_num]

        while post['chat_id'] == None:
            self.deletepostsilent(post['post_id'])
            random_num = randint(0,posts.count()-1)
            post = posts[random_num]
        if post['chat_id'] == "@SeenMeUp":
           post['chat_id'] == "@SeenMeUpPlease"

        m=0
        #try:
        if self:
            bot.sendChatAction(self.user_id, "typing")
            time.sleep(0.75)
            f = 0
            while f == 0:
             try:
                print("inja2")
                bot.forwardMessage(self.user_id, post['chat_id'], post['msg_id'])
                self.updateinfo({"viewedads":self.viewedads+1})
                f = 1
                m=1
                print("injas3")
             except  Exception as e:
                  print(e)
                  if 'forward not found' in str(e):
                      self.deletepostsilent(post['post_id'])
                      random_num = randint(0,posts.count()-1)
                      post = posts[random_num]
                  #    f =1

                 # f=1
                  if 'parameters' in e.args[2] and 'retry_after' in e.args[2]['parameters']:
                     timenow = time.strftime("%H:%M:%S", time.gmtime(e.args[2]['parameters']['retry_after']))
                     f=1
                     bot.sendMessage(self.user_id,"ربات فعلا قادر به پاسخگویی نمیباشد\nاین مشکل به دلیل وجود محدودیت های تلگرام در فروارد کردن پیام ها به وجود امده است\nمدت زمان رفع محدودیت: {} دیگر".format(timenow))
                  return
             #except Exceprion as e:
             #  print(e)
            db.posts.update_one({'post_id':post['post_id']}, {'$set':{"views":post['views']-1},"$push": {'viewed': self.user_id}})
            post = db.posts.find({'post_id':post['post_id']}).limit(1)[0]
            if post['views'] <= 0:
                try:
                    bot.editMessageText((post['channel_id'], post["channel_msg_id"]),"تعداد بازدید ها انجام شد")
                    bot.sendMessage(post['sender_id'],"تعداد بازدیدهای سفارش {} انجام شد".format(post['post_id']))
                except Exception as e:
                    print(e)
                db.posts.update_one({'post_id':post['post_id']}, {'$set':{"finished":True}})
                
                
            self.updateinfo({'total_coin':self.total_coin+1})
            self.updateinfo({'coin':self.coin+1})
            return
        #except Exception as e:
           #  bot.sendMessage(self.user_id,"ربات فعلا قادر به پاسخگویی نمیباشد لطفا بعدا دوباره امتحان کنید")
        #     bot.sendMessage(271547669,str(e))
