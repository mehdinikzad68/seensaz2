import os
import asyncio
import redis
import telepot
import telepot.aio
import json
import importlib
import urllib.request as r
import requests
from langs import lang
import sys
import re
import time
from termcolor import colored
from pymongo import MongoClient
import threading
from telepot.namedtuple import *
import config
price = [20,50,100,200,500,1000,2000]
buycoin = [250,500,1000,2000,5000,10000,20000,50000,100000]
sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf8', buffering=1)
#---- Redis
pool = redis.ConnectionPool(host='localhost', port=6379,decode_responses=True)
ttl = redis.Redis(connection_pool=pool)
#---- MongoDB
client = MongoClient('localhost:27017')
db = client.arian.seensaz2
#---- BOT
bot = telepot.Bot(config.TOKEN)
#---- GetMe (BOT INFO)
botinfo = bot.getMe()
botuser="viewsazrobot"
#---- 
def update_user(msg):

    last_name = msg['from']['last_name'] if 'from' in msg and 'last_name' in msg['from'] else None
    username = msg['from']['username'] if 'from' in msg and 'username' in msg['from'] else None
    data = {"user_id":msg['from']['id'],"first_name":msg['from']['first_name'],"last_name":last_name,"username":username}
    result = db.users.update_one({'user_id':msg['from']['id']}, {'$set':data}, upsert=True)


def is_sudo(user_id):

    return user_id in config.sudo_users

