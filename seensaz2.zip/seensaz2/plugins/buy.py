from __main__ import *
from utils import *
import math
patterns = [
r'.*',
]
name = "start"
cron = None
def run(msg, matches, User):
    if '💳 فروشگاه' in msg['text']:
       #if msg:
        #    return bot.sendMessage(User.user_id, 'به زودی')
        keyboard = generate_keyboard_buy()
        bot.sendMessage(User.user_id,'🎯 برای خرید روی یکی از گزینه های زیر کلیک کنید.',reply_markup=keyboard)
        User.updateinfo({'step':'buy_coin'})
        return

    if User.step =='buy_coin':
        matches = re.match(r'([\d]+)', msg['text'])
        if matches:
            matches = matches.groups()[0]
            text = matches
        else:
            return
        if not 'انصراف' in msg['text'] and int(matches) in buycoin:
            User.updateinfo({'step':False})
            k = InlineKeyboardMarkup(inline_keyboard=[[ InlineKeyboardButton(text='برای خرید کلیک کنید', url=User.buycoin(matches))]])
            bot.sendMessage(User.user_id,'برای خرید {} روی دکمه زیر کلیک کنید'.format(text),reply_markup=k)
        #else:
            #User.updateinfo({'step':False})
            #bot.sendMessage(User.user_id,'Error',reply_markup=default_keyboard)
