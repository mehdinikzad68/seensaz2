from __main__ import *
from utils import *
import math

patterns = [
    r'^[#/!](addcoin) ([\S\d]+) ([\d]+)$',
    r'^[#/!](setcoin) ([\S\d]+) ([\d]+)$',
    r'^[#/!](remcoin) ([\S\d]+) ([\d]+)$',
    r'^[#/!](users)',
    r'^[#/!](bc)',
    r'^[#/!](bc2)',
    r'^[#/!](stats)',
    r'^[#/!](setcreator)',
    r'^[#/!](storebot)',
    r'^[#/!](pm) ([\S\d]+) (.*)',
    r'^[#/!](members)',
    r'^[#/!](check) ([\S\d]+)$',
    r'^[#/!](echo) (.*)$',
    r'^[#/!](setref) ([\S\d]+)$',
    r'^!!callback (block) ([\S]+)$',
    r'^!!callback (unblock) ([\S]+)$',
    r'^!!callback (remove) ([\S]+)$',
    r'(.*)'
]
name = "start"
cron = None


def keyboard(array):
    kb = []
    kb2 = []
    for i in array:
        for a in i:
            kb2.append(KeyboardButton(text=a))
        kb.append(kb2)
        kb2 = []
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True, one_time_keyboard=False)


def run(msg, matches, User):
    if matches[0] == 'users':
        if is_sudo(msg['from']['id']):  
            users= db.users.find().sort('coin',-1).limit(20)
            a = ''
            for i in users:
                a += 'ID: {} | coin: {} | name: {}\n\n'.format(i['user_id'],i['coin'],i['first_name'])
            bot.sendMessage(msg['chat']['id'],a)
    if 'caption' in msg:
        if is_sudo(msg['from']['id']):
            bot.sendMessage(msg['chat']['id'], msg)
    if matches[0] == 'setcreator' and is_sudo(User.user_id):
        text = msg['text'].replace('/setcreator ', '')
        ttl.set('creator', text)
        bot.sendMessage(User.user_id, text)
    if matches[0] == 'echo' and is_sudo(User.user_id):
        bot.sendMessage(User.user_id, matches[1], reply_markup=default_keyboard)
    if matches[0] == "storebot" and is_sudo(User.user_id):
        a = 0
        users = db.users.find({"stars": {"$exists": False}})
        bot.sendMessage(User.user_id, "پیام به زود ارسال میشود", reply_markup=default_keyboard)
        for i in users:
            try:

                bot.sendPhoto(i['user_id'], "AgADBAADDKgxG0ZxwVGe_y9uun5J_BO5ZBkABBNwgTCAaST6mIADAAEC")
                bot.sendMessage(i['user_id'], lang['storebot2'], disable_web_page_preview=True)
                print('ok')
                a += 1
            except:
                print('failed')
                # User.updateinfo({"bot_blocked":True})
        for i in config.sudo_users:
            bot.sendDocument(i, "CgADBAADBgADEaSwUaZWvi6jf-IUAg", caption=lang['storebot2'])
            bot.sendMessage(i, "پیام به {} نفر ارسال شد\nتعداد پیام های ارسال نشده: {}".format(a, users.count() - a),
                            reply_markup=default_keyboard)
    if is_sudo(User.user_id) and matches[0] == 'pm':
        bot.sendMessage(matches[1], "پیام از طرف پشتیبانی:\n\n{}".format(matches[2]))
    if matches[0] == 'members' and is_sudo(User.user_id):
        file = open('members.json', 'w')
        data = []
        for i in db.smembers('botusers'):
            try:
                userid = i
                coin = db.get('coin:' + str(i))
                if not coin:
                    coin = 0
                data.append({'id': userid, 'coin': coin})

            except:
                a = None
        file.write(str(data))
        file.close()
        bot.sendDocument(User.user_id, 'members.json')
    if matches[0] == 'setref' and is_sudo(User.user_id):
        if int(matches[1]) == 0:
            ttl.delete('server:ref')
        else:
            ttl.set('server:ref', int(matches[1]))
        bot.sendMessage(User.user_id, 'ساعت طلایی به {} ست شد'.format(matches[1]), reply_markup=default_keyboard)
    if matches[0] == 'stats' and is_sudo(User.user_id):
        totalmsgs = ttl.get('totalmsgs')
        users = db.users.find({"bot_blocked": {"$ne": True}}).count()
        posts = db.posts.find({'finished': False}).count()
        postsa = db.posts.find().count()
        text = 'تعداد اعضا: {}\nتعداد پست ها: {} از {}\nتعداد پیام ها: {}'.format(users, posts, postsa, totalmsgs)
        bot.sendMessage(User.user_id, text, reply_markup=default_keyboard)
    if matches[0] == 'check' and is_sudo(User.user_id):
        coin = db.get('coin:' + str(matches[1]))
        coin = str(coin) if coin else 'کاربر پیدا نشد'
        return bot.sendMessage(User.user_id, coin, reply_markup=default_keyboard)

    if matches[0] == 'بله' and is_sudo(User.user_id):
        a = 0
        text = ttl.get("server:bc")
        if text:
            users = db.users.find({"bot_blocked": {"$ne": True}})
            bot.sendMessage(User.user_id, "پیام به زودی به {} نفر ارسال میشود".format(users.count()),
                            reply_markup=default_keyboard)
            for i in users:
                try:
                    print('ok')
                    bot.sendMessage(i['user_id'], text, reply_markup=default_keyboard)
                    a += 1
                except:
                    print('failed')
                    updateinfo(i['user_id'], {"bot_blocked": True})
            ttl.delete("server:bc")
            for i in config.sudo_users:
                bot.sendMessage(i,
                                "پیام به {} نفر ارسال شد\nتعداد پیام های ارسال نشده: {}".format(a, users.count() - a),
                                reply_markup=default_keyboard)
    if matches[0] == 'نه' and is_sudo(User.user_id):
        ttl.delete("server:bc")
        bot.sendMessage(User.user_id, "ارسال لغو شد", reply_markup=default_keyboard)
    if matches[0] == 'bc' and is_sudo(User.user_id):
        text = msg['text'].replace("/bc ", '')
        ttl.set("server:bc", text)
        bot.sendMessage(User.user_id, text + "\n\nآیا مطمئن هستید؟", reply_markup=keyboard([['بله', 'نه']]))
    if matches[0] == 'block':
        bot.answerCallbackQuery(msg["id"], "کاربر بلاک شد", False)
        post = db.posts.find({'post_id': matches[1]})[0]
        db.users.update_one({'user_id': post['sender_id']}, {'$set': {'blocked': True}})
        k = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text='انبلاک کردن کاربر', callback_data="unblock {}".format(matches[1]))],
            [InlineKeyboardButton(text='حذف تبلیغ', callback_data="remove {}".format(matches[1]))]])
        a = bot.editMessageText((msg["chat"]["id"], msg["message_id"]), "انجام عملیات", reply_markup=k)
        print(a)
        return
    if matches[0] == 'remove':
        print('injaas')
        bot.answerCallbackQuery(msg["id"], "پست پاک شد", False)
        User.deletepost(matches[1])
        bot.editMessageText((msg["chat"]["id"], msg["message_id"]), "پست پاک شد")
        return
    if matches[0] == 'unblock':
        bot.answerCallbackQuery(msg["id"], "کاربر انبلاک شد", False)
        post = db.posts.find({'post_id': matches[1]})[0]
        db.users.update_one({'user_id': post['sender_id']}, {'$set': {'blocked': False}})
        k = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text='بلاک کردن کاربر', callback_data="block {}".format(matches[1]))],
            [InlineKeyboardButton(text='حذف تبلیغ', callback_data="remove {}".format(matches[1]))]])
        bot.editMessageText((msg["chat"]["id"], msg["message_id"]), "انجام عملیات", reply_markup=k)
        return

    if matches[0] == 'addcoin' and is_sudo(User.user_id):
        User.updateinfo({"coin": int(matches[2]) + User.coin})
        return bot.sendMessage(User.user_id,
                               'به کاربر {} تعداد {} سکه اضافه شد\nتعداد سکه های فعلی: {}'.format(matches[1],
                                                                                                  matches[2],
                                                                                                  int(matches[2]) + int(
                                                                                                      User.coin)),
                               reply_markup=default_keyboard)
    if matches[0] == 'remcoin' and is_sudo(User.user_id):

        User.updateinfo({"coin": User.coin - int(matches[2])})
        return bot.sendMessage(User.user_id,
                               'به کاربر {} تعداد {} سکه کسر شد\nتعداد سکه های فعلی: {}'.format(matches[1], matches[2],
                                                                                                int(User.coin) - int(
                                                                                                    matches[2])),
                               reply_markup=default_keyboard)
    if matches[0] == 'setcoin' and is_sudo(User.user_id):
        updateinfo(int(matches[1]), {"coin": int(matches[2])})
        return bot.sendMessage(User.user_id, 'سکه های کاربر {} به {} تنظیم شد'.format(matches[1], matches[2]),
                               reply_markup=default_keyboard)

    if is_sudo(User.user_id) and 'reply_to_message' in msg:
        if '!!' in msg['text']:
            return
        if 'forward_from' in msg['reply_to_message']:
            bot.sendMessage(msg['reply_to_message']['forward_from']['id'],
                            "پیام از طرف پشتیبانی:\n\n{}".format(msg['text']))
            bot.sendMessage(User.user_id, 'پیام شما ارسال شد')
            return
