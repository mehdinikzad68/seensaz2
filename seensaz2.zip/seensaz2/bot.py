from core import *
import requests
plugins = []


def load_bot():
    #print bot info
    print(bot.getMe())
    #load_plugins
    for x in os.listdir('plugins'):
        if(x.endswith('.py') and not 'init' in x):
            module_name = 'plugins' + '.' + x.split('.')[0]
            plugins.append(importlib.import_module(module_name))
            print(colored("Plugin " + x.split('.')[0]+ " loaded","red"))


@asyncio.coroutine
def download(file_id, path):
    yield from bot.download_file(file_id, path)
    return path

    
    
    
def cronjob():
    bot2 = telepot.Bot(config.TOKEN)
    try:
        while True:

            resp = requests.get("https://storebot.me/api/bots/reviews?id=VIEWSAZ2017BOT&count=50")
            data = demjson.decode(resp.text)
            for i in data:
              try:
                userid = i['userId']
                user = db.users.find({"user_id":int(userid)})
                user = user[0] if user.count() != 0 else None
                if user != None:
                    coin = user['coin'] if 'coin' in user else 0
                    stars = '⭐️'*i['stars']
                    if not 'stars' in user or user['stars'] != i['stars']:
                        if i['stars'] == 5:
                            if not 'stars' in user or user['stars'] != 5:

                                bot2.sendMessage(userid," شما {} ستاره به ربات داده اید ({})\n✳️ نظر شما: {}\n\n30 سکه به شما اضافه میشود".format(i['stars'],stars,i['review']),disable_web_page_preview=True)
                                db.users.update_one({'user_id':int(userid)}, {'$set':{"stars":i['stars'],"coin":coin+30}})
                        else:
                            if user['stars'] == 5:
                                bot2.sendMessage(userid," شما {} ستاره به ربات داده اید ({})\n✳️ نظر شما: {}\n\n30 سکه از شما کسر میشود\nبرای دریافت مجدد سکه ها باید حتما 5 ستاره امتیاز بدهید\nبرای ثبت مجدد امتیاز روی لینک زیر کلیک کنید:\ntelegram.me/storebot?start=ViewRobot\nیادت باشه حتما نظرت رو در مورد ربات ثبت کنی که 30 سکه بهت اضافه بشه".format(i['stars'],stars,i['review']),disable_web_page_preview=True)
                                db.users.update_one({'user_id':int(userid)}, {'$set':{"coin":coin-30}})
                            else:
                                bot2.sendMessage(userid," شما {} ستاره به ربات داده اید ({})\n✳️ نظر شما: {}\n\nبرای دریافت 30 سکه باید حتما 5 ستاره امتیاز بدهید\nبرای ثبت مجدد امتیاز روی لینک زیر کلیک کنید:\ntelegram.me/storebot?start=ViewRobot\nیادت باشه حتما نظرت رو در مورد ربات ثبت کنی که 30 سکه بهت اضافه بشه".format(i['stars'],stars,i['review']),disable_web_page_preview=True)
                            db.users.update_one({'user_id':int(userid)}, {'$set':{"stars":i['stars']}})
              except:
                None
            time.sleep(4)
    except:
        pass
                    
    
cron = threading.Thread(target = cronjob)
cron.start()

load_bot()
@asyncio.coroutine
def msg_processor(msg):
    if 'chat' in msg and  msg['from']['id'] != msg['chat']['id']:
        return
#    if msg:
#      return
    ttl.incr('totalmsgs')
    update_user(msg)


    user = User(msg)
    user.updateinfo({'count':user.count+1})
    if not user.is_reffered:
        user.updateinfo({'is_reffered': True})
        user.updateinfo({'coin': user.coin + 10})
    #if user.storebot > 8 and user.stars != 5:
    #    user.updateinfo({'storebot':0})
    #    yield from bot.sendDocument(user.user_id,"CgADBAADBgADEaSwUaZWvi6jf-IUAg" ,caption=lang['storebot2'])
    #else:
    #    user.updateinfo({'storebot':1+user.storebot})
    if 'contact' in msg and 'user_id' in msg['contact'] and not user.phone:
        if msg['contact']['user_id'] == msg['from']['id']:
            user.updateinfo({'phone':msg['contact']['phone_number']})
            user.updateinfo({'coin':user.coin+15})
            yield from bot.sendMessage(user.user_id,'شماره تلفن شما با موفقیت ذخیره شد و ۱۵ سکه به حساب کاربری شما اضافه شد',reply_markup=default_keyboard)
    msg['text'] = msg['text'] if 'text' in msg else ''
    msg['text'] = msg['caption'] if 'caption' in msg else msg['text']
    if "data" in msg:
        msg["chat"] = {}
        msg["chat"]["type"] = "callback"
        msg["text"] = "!!callback " + msg["data"]
        if "message" in msg:
            msg["chat"]["id"] = msg["message"]["chat"]["id"]
            msg["message_id"] = msg["message"]["message_id"]
    if "query" in msg:
        msg["chat"] = {}
        msg["chat"]["type"] = "inline"
        msg["text"] = "!!inline " + msg["query"]
    text = "{} | {} | coin: {} | refs: {} | phone: {} | msgs: {}".format(user.user_id,user.username,user.coin,user.refs,user.phone,user.count)
    print(colored("{}: ".format(msg['from']['first_name']),"red")+colored("{}\n".format(msg['text'].replace("\n",' ')[:15]),"yellow")+colored("{}\n\n".format(text),"white"))
    if is_sudo(msg['from']['id']):
        print(msg)

    if "text" in msg or "caption" in msg:
        for plugin in plugins:
            for k in plugin.patterns:
                if re.match(k, msg["text"]):
                    matches = list(re.match(k, msg["text"]).groups())
                    res = threading.Thread(target = plugin.run, args=(msg, matches,user))
                    res.start()

bot = telepot.aio.Bot(config.TOKEN)
answerer = telepot.aio.helper.Answerer(bot)
loop = asyncio.get_event_loop()
loop.create_task(bot.message_loop({'chat': msg_processor,'callback_query': msg_processor,'inline_query': msg_processor,}))
print('Bot Started')
loop.run_forever()
