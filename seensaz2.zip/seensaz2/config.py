sudo_users = [379856063,127672374,387777412]
TOKEN = "384737536:AAG9ghfR8z5lJLMmUUSxEh1bGrWapJEGkOo"
channel = "@viewsazadmin"
channel2 = "@viewsazrobo"
adschannel = "@viewsazads"